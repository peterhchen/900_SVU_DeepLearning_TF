import base64
import numpy as np
import io
#from io import BytesIO
import re
# Python Image Library 
# > conda install pillow
from PIL import Image
import keras
from tensorflow.keras import backend as K
from tensorflow.keras.models import Sequential
#from tensorflow.keras.models import load_model
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.preprocessing.image import img_to_array
from flask import request
from flask import jsonify
import json
from flask import Flask

app = Flask(__name__)

def get_model():
    global model
    #model = load_model('VGG16_cats_and_dogs.h5')
    # VGG16_cats_and_dogs.h5 is 500MB is to big to download
    # https://github.com/prashant0598/Keras-Machine-Learning-Deep-Learning-Tutorial/tree/master/flask_apps
    # new_model = load_model('models/medical_trial_model.h5')
    # I save the VGG16_cats_and_dogs.h5 from sec03_TF_VGG16 in Episode 15: TrainFineTuneVGG16.
    model = load_model('../../models/VGG16_cats_and_dogs.h5')
    print(" * Model loaded!")

def preprocess_image(image, target_size):
    if image.mode != "RGB":
        image = image.convert("RGB")
    image = image.resize(target_size)
    image = img_to_array(image)
    image = np.expand_dims(image, axis=0)

    return image


print(" * Loading Keras model...")
get_model()

@app.route("/predict", methods=["POST"])
def predict():
    print('called @app.route("/predict", methods=["POST"])')
    print()
    # Client:
    # let message = {
    #   image: base64Image
    # }
    message = request.get_json(force=True)

    encoded = message['image']
    # https://stackoverflow.com/questions/26070547/decoding-base64-from-post-to-use-in-pil
    #image_data = re.sub('^data:image/.+;base64,', '', message['image'])
    image_data = re.sub('^data:image/.+;base64,', '', encoded)
    # Remove extra "data:image/...'base64" is Very important
    # If "data:image/...'base64" is not remove, the following line generate an error message: 
    # File "C:\Work\SVU\950_SVU_DL_TF\sec07_TF_Flask06_09\32_KerasFlask06_VisualD3\32_predict_app.py", line 69, in predict
    # image = Image.open(io.BytesIO(decoded))
    # File "C:\Users\14088\anaconda3\envs\tensorflow\lib\site-packages\PIL\Image.py", line 2968, in open
    # "cannot identify image file %r" % (filename if filename else fp)
    # PIL.UnidentifiedImageError: cannot identify image file <_io.BytesIO object at 0x000002B733BB11C8>
    # image = Image.open(BytesIO(base64.b64decode(image_data)))
    decoded = base64.b64decode(image_data)
    image = Image.open(io.BytesIO(decoded))
    # return json.dumps({'result': 'success'}), 200, {'ContentType': 'application/json'}
    #print('@app.route => image:')
    #print()
    processed_image = preprocess_image(image, target_size=(224, 224))
    
    prediction = model.predict(processed_image).tolist()
    #print('prediction:', prediction)
    response = {
        'prediction': {
            'dog': prediction[0][0],
            'cat': prediction[0][1]
        }
    }
    print('response:', response)
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)